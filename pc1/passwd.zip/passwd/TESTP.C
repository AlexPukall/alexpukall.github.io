/* TESTP.C */
/* written in Borland Turbo C 2.0 on PC */
/* Test if the user password is correct or not, read PASSWD.TXT */
/* By Alexander PUKALL 1991 */
/* free code no restriction to use */
/* please include the name of the Author in the final software */
/* the Key is 256 bits */
/* Tested with Turbo C 2.0 for DOS and Microsoft Visual C++ 5.0 for Win 32 */

#include <stdio.h>
#include <string.h>
unsigned short ax,bx,cx,dx,si,tmp,x1a2,x1a0[16],res,i,inter,cfc,cfd,compte;
unsigned char cle[32]; /* vars are global */
unsigned char buff[32],buff1[255],buff2[255];
unsigned char name[255],name1[255];
short c;
int c1,count,t1;
short d,e;

FILE *in;

fin()
{
/* erase all variables */

for (compte=0;compte<=31;compte++)
{
cle[compte]=0;
}
ax=0;
bx=0;
cx=0;
dx=0;
si=0;
tmp=0;
x1a2=0;
x1a0[0]=0;
x1a0[1]=0;
x1a0[2]=0;
x1a0[3]=0;
x1a0[4]=0;
res=0;
i=0;
inter=0;
cfc=0;
cfd=0;
compte=0;
c=0;

exit(0);
return(0);
}

assemble()
{

x1a0[0]= ( cle[0]*256 )+ cle[1];
code();
inter=res;

x1a0[1]= x1a0[0] ^ ( (cle[2]*256) + cle[3] );
code();
inter=inter^res;

x1a0[2]= x1a0[1] ^ ( (cle[4]*256) + cle[5] );
code();
inter=inter^res;

x1a0[3]= x1a0[2] ^ ( (cle[6]*256) + cle[7] );
code();
inter=inter^res;

x1a0[4]= x1a0[3] ^ ( (cle[8]*256) + cle[9] );
code();
inter=inter^res;

x1a0[5]= x1a0[4] ^ ( (cle[10]*256) + cle[11] );
code();
inter=inter^res;

x1a0[6]= x1a0[5] ^ ( (cle[12]*256) + cle[13] );
code();
inter=inter^res;

x1a0[7]= x1a0[6] ^ ( (cle[14]*256) + cle[15] );
code();
inter=inter^res;

x1a0[8]= x1a0[7] ^ ( (cle[16]*256) + cle[17] );
code();
inter=inter^res;

x1a0[9]= x1a0[8] ^ ( (cle[18]*256) + cle[19] );
code();
inter=inter^res;

x1a0[10]= x1a0[9] ^ ( (cle[20]*256) + cle[21] );
code();
inter=inter^res;

x1a0[11]= x1a0[10] ^ ( (cle[22]*256) + cle[23] );
code();
inter=inter^res;

x1a0[12]= x1a0[11] ^ ( (cle[24]*256) + cle[25] );
code();
inter=inter^res;

x1a0[13]= x1a0[12] ^ ( (cle[26]*256) + cle[27] );
code();
inter=inter^res;

x1a0[14]= x1a0[13] ^ ( (cle[28]*256) + cle[29] );
code();
inter=inter^res;

x1a0[15]= x1a0[14] ^ ( (cle[30]*256) + cle[31] );
code();
inter=inter^res;

i=0;
return(0);
}

code()
{
dx=x1a2+i;
ax=x1a0[i];
cx=0x015a;
bx=0x4e35;

tmp=ax;
ax=si;
si=tmp;

tmp=ax;
ax=dx;
dx=tmp;

if (ax!=0)
{
ax=ax*bx;
}

tmp=ax;
ax=cx;
cx=tmp;

if (ax!=0)
{
ax=ax*si;
cx=ax+cx;
}

tmp=ax;
ax=si;
si=tmp;
ax=ax*bx;
dx=cx+dx;

ax=ax+1;

x1a2=dx;
x1a0[i]=ax;

res=ax^dx;
i=i+1;
return(0);
}
main()
{
unsigned int x,ix,z,fin1;
unsigned char tab[32]; /* HASH */

x=32; /* Size of the HASH */
si=0;
x1a2=0;
i=0;

strcpy(cle,"abcdefghijklmnopqrstuvwxyz012345"); /* this is not a password, only a random string */
/* it must be the same in the PASSWD.C and in the TESTP.C */

printf ("PC1 Password Encryptor 256 bits \nENCRYPT Passwords into the passwd.txt file\n\n");

if ((in=fopen("passwd.txt","rb")) == NULL) {printf("\nError reading file PASSWD.TXT !\n");fin();}

printf("Enter the login name:");
gets(name);

while ( (fgets(name1,255,in)) != NULL) /* test the login name */
{
name1[strlen(name1)-2]=0; /* remove the 0x0d and 0x0a at the end of the name */

if (strcmp(name,name1)==0) /* the login name was found in the passwd.txt file */
{
fgets(buff1,65,in); /* then read the password in the passwd.txt file */

printf("Enter password (max 32 chars):");
gets(buff);

if (strlen(buff)>32)
{ count=32; }
else
{count=strlen(buff);}

for (c1=0;c1<count;c1++)
{
 cle[c1]=buff[c1];
}

ix=0;

for (z=0;z<=x;z++)
{
tab [z]=0;
}

for (c1=0;c1<32;c1++)
{

c=cle[c1];
assemble();
cfc=inter>>8;
cfd=inter&255; /* cfc^cfd = random byte */

for (compte=0;compte<=31;compte++)
{
cle[compte]=cle[compte]^c;
}

c = c ^ (cfc^cfd);

tab [ix] = tab [ix] ^ c;

ix = ix + 1;
if ( ix >= x ) ix = 0;
}

fin1 = 63254; /* to avoid dictionary attack on the passwords */

for (z=1;z<=fin1;z++)
{

c = tab [ix];

assemble();
cfc=inter>>8;
cfd=inter&255; /* cfc^cfd = random byte */

for (compte=0;compte<=31;compte++)
{
cle[compte]=cle[compte]^c;
}

c = c ^ (cfc^cfd);

tab [ix] = tab [ix] ^ c;

ix = ix + 1;
if ( ix >= x ) ix = 0;

}

t1=0;
for (z=0;z<x;z++)
{
 

d=(tab[z] >> 4); /* we split the 'c' crypted byte into two 4 bits parts 'd' and 'e' */
e=(tab[z] & 15);

buff2[t1]=d+0x61; /* write the two 4 bits parts in the passwd.txt as text range from A to P */
buff2[t1+1]=e+0x61;
t1=t1+2;

}

if (strcmp(buff1,buff2)==0) /* the password is correct */
{
  printf("\nPassword is correct !\n");
  fclose(in);
  fin();
}
else
{
  printf("\nPassword is INCORRECT !\n");
  fclose(in);
  fin();
}

}

}

  printf("The login name was not found in the passwd.txt file !\n");


fclose(in);
fin();

return(0);
}