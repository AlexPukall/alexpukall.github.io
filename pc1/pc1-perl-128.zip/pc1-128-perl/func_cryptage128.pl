#PC1 Cipher 128 bits

use integer;
$| = 1;
$mask=65535;

sub chainecrypt {

$si=0;	$x1a2=0; $i=0; $final='';
$chaine_in=$_[0];
$cle=$_[1];
$long_cle=length $cle;

	if ($long_cle != 16)
	{ print "The password must be 16 chars long!! \n";
	exit(0);
	}

for ($y=0; $y<16; $y++) { $clef[$y]=substr ($cle, $y ,1); }	#en c : strcopy(cle,argv[3])

$long=length($chaine_in);
for ($y=0; $y<$long; $y++) { 
		
	$carac=substr ($chaine_in, $y ,1); 
	$oct=(ord $carac) & $mask;		#donne la valeur ascii de $carac
		&assemble;
		$cfc=$inter>>8;
		$cfd=$inter & 255;
# ZONE K 
		for ($compte=0; $compte<=15 ; $compte++)
			{
			$clef[$compte] = (ord($clef[$compte])^$oct) ;
			$clef[$compte] =pack "c", $clef[$compte];
			}
		$oct=$oct^ ($cfc^$cfd);
		$decoup1=($oct>>4)+0x61;		#decoupage en 2 lettres
		$decoup2=($oct&15)+0x61;		#fourchette de a � n (15 possibilites)

		$decoup1=pack "c", $decoup1;
		$decoup2=pack "c", $decoup2;
		$final=$final . ($decoup1 . $decoup2);
				}	
		&fin;
		return ($final);		
		}

sub chainedecrypt  {		#ss fonction de decryptage d'une chaine 

	$si=0;	$x1a2=0; $i=0; $final='';
	$chaine_in=$_[0];
	$cle=$_[1];
	$long_cle=length $cle;

	if ($long_cle != 16)
	{ print "The password must be 16 chars long !! \n";
	exit(0);
	}

for ($y=0; $y<16; $y++) { $clef[$y]=substr ($cle, $y ,1); }	#en c : strcopy(cle,argv[3])

$long=length($chaine_in);
for ($y=0; $y<$long; $y++) { 
		
		$carac=substr ($chaine_in, $y ,1); 
		$oct=((ord $carac)-0x61) & $mask;		#donne la valeur ascii de $carac.
		$oct=$oct<<4;				#decalage pour pds fort.
		$y=$y+1;
		$carac=substr ($chaine_in, $y ,1); 
		$oct=$oct+((ord $carac)-0x61) & $mask;
		&assemble;
		$cfc=$inter>>8;
		$cfd=$inter & 255;
# ZONE K 
		$oct=$oct^ ($cfc^$cfd);
		for ($compte=0; $compte<=15 ; $compte++)
			{
			$clef[$compte] = (ord($clef[$compte])^$oct) ;
			$clef[$compte] =pack "c", $clef[$compte];
			}
		$oct=pack "c",$oct;		  #fonction "pack" convertit en 1 caractere la $oct.
		$final=$final . ($oct);
	                                        }
		&fin;
		return ($final);		
	     		}
	
sub assemble  {
		 $x1a0[0]=((ord ($clef[0])*256)+ (ord $clef[1]));
		 $x1a0[0]=$mask & $x1a0[0];  
		 &code;
		 $inter=$res & $mask;
			 
  		 $x1a0[1]=$x1a0[0]^((ord ($clef[2])*256)+ (ord $clef[3]));
                    $x1a0[1]=$mask & $x1a0[1]; 
		 &code;
		 $inter=($inter^$res) & $mask;
	
		 $x1a0[2]=$x1a0[1]^((ord ($clef[4])*256)+ (ord $clef[5]));
		 $x1a0[2]=$mask & $x1a0[2]; 
                    &code;
		 $inter=($inter^$res) & $mask;
	
		 $x1a0[3]=$x1a0[2]^((ord ($clef[6])*256)+ (ord $clef[7]));
                    $x1a0[3]=$mask & $x1a0[3]; 
		 &code;
		 $inter=($inter^$res) & $mask;
	
		 $x1a0[4]=$x1a0[3]^((ord ($clef[8])*256)+ (ord $clef[9]));
		 $x1a0[4]=$mask & $x1a0[4]; 
                    &code;
		 $inter=($inter^$res) & $mask;
	 	 
		 $x1a0[5]=$x1a0[4]^((ord ($clef[10])*256)+ (ord $clef[11]));
		 $x1a0[5]=$mask & $x1a0[5]; 
                    &code;
		 $inter=($inter^$res) & $mask;

		 $x1a0[6]=$x1a0[5]^((ord ($clef[12])*256)+ (ord $clef[13]));
		 $x1a0[6]=$mask & $x1a0[6]; 
                    &code;
		 $inter=($inter^$res) & $mask;

		 $x1a0[7]=$x1a0[6]^((ord ($clef[14])*256)+ (ord $clef[15]));
		 $x1a0[7]=$mask & $x1a0[7]; 
                    &code;
		 $inter=($inter^$res) & $mask;

		 $i=0;
		 }

sub code	 {
		 $dx=($x1a2+$i) & $mask;
		 $ax=($x1a0[$i]) & $mask;
		 $cx=0x015a;
		 $bx=0x4e35;
		
		 $tmp=$ax;
		 $ax=$si;
		 $si=$tmp;
		 
		 $tmp=$ax;
		 $ax=$dx;
		 $dx=$tmp;
		 
	if ($ax!=0) {  $ax=$ax*$bx;
 	          	$ax=$mask & $ax; }		
		 
		 $tmp=$ax;
		 $ax=$cx;
                    $cx=$tmp;

	if ($ax!=0) {	$ax=$ax*$si; 
			$ax=$mask & $ax;
			$cx=$ax+$cx; 
			$cx=$mask & $cx; }

		 $tmp=$ax;
		 $ax=$si;
		 $si=$tmp;
		 $ax=($ax*$bx) & $mask;
	           $dx=($cx+$dx) & $mask;
		 $ax=($ax+1) & $mask;
	 	 $x1a2=$dx;
		 $x1a0[$i]=$ax;
		 
		 $res=($ax^$dx) & $mask;
                 	 $i=$i+1;
		 }


sub fin		{
		# on quitte l'algorithme en reinitialisant toutes les variables.
		
                for ($compte=0; $compte<=15; $compte++)
		{ 	$clef[compte]=0;	}

		$ax=0; $bx=0; $cx=0; $dx=0; $si=0; $tmp=0; $x1a2=0; 
		$x1a0[0]=0; $x1a0[1]=0; $x1a0[2]=0; $x1a0[3]=0; $x1a0[4]=0;
		$x1a0[5]=0; $x1a0[6]=0; $x1a0[7]=0;
		$res=0; $i=0; $inter=0; $cfc=0; $cfd=0; $compte=0; $carac=0; $oct=0;
		$decoup1=0; $decoup2=0;
		}
