Contents of this zipfile:

control.zip - Compiled PC1 ActiveX binary.
sample.zip - Example project for the PC1 ActiveX Control
source.zip - PC1 ActiveX Source code

This ActiveX control was based on Alexander Pukall's VB4 code for his PC1 encryption algorithm.  This version only supports 128-bit keys, the next version will support both 128-bit AND 80-bit keys.  
This ActiveX control was developed with Visual Basic 6.0 Professional Edition, so you need the VB6 runtime files in order to use it.

Visit Alexander Pukall's PC1 homepage at: http://www.multimania.com/pc1/index.html

This ActiveX control is freeware.

Dan "Wraith" Hetrick
wraith@planetshogo.com
