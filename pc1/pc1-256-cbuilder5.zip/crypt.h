/*
   ################################################
   #                                              #
   #  PC1 CIPHER 256-bit keys ~ Alexander Pukall  #
   #  (c) NERRANT THOMAS ~ February 2003          #
   #  http://thomasnerrant.com                    #
   #                                              #
   ################################################

   ################################################
   #                                              #
   #  Modified for CBuilder 5                     #
   #  Tom Crawford                                #
   #  March 2003                                  #
   #                                              #
   ################################################
*/
//---------------------------------------------------------------------------
#ifndef cryptH
#define cryptH
//---------------------------------------------------------------------------
class TPasswordEncryptDecrypt
{
private:
	void __fastcall initVars ();
	void __fastcall common (String inText, String inKey);
	unsigned short __fastcall code ();
	unsigned short __fastcall assemble ();

   String m_cle;
	unsigned short m_x1a0[16], m_x1a2, m_ax, m_bx, m_cx, m_dx, m_si, m_cntr;

public:
	__fastcall TPasswordEncryptDecrypt ();
	__fastcall ~TPasswordEncryptDecrypt ();

   String __fastcall encryptMe (String inText, String inKey);
	String __fastcall decryptMe (String inText, String inKey);
};
//---------------------------------------------------------------------------
#endif
