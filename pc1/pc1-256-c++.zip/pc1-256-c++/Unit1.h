//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// Composants g�r�s par l'EDI
        TPanel *Panel1;
        TButton *Button1;
        TButton *Button2;
        TPanel *Panel2;
        TLabel *Label1;
        TEdit *Edit1;
        TGroupBox *GroupBox1;
        TGroupBox *GroupBox2;
        TRichEdit *RichEdit1;
        TRichEdit *RichEdit2;
        TLabel *Label2;
        TPopupMenu *PopupMenu1;
        TMenuItem *Undo1;
        TMenuItem *N1;
        TMenuItem *Copy1;
        TMenuItem *Paste1;
        TMenuItem *Delete1;
        TMenuItem *N2;
        TMenuItem *Selectall1;
        void __fastcall Label2Click(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Undo1Click(TObject *Sender);
        void __fastcall Copy1Click(TObject *Sender);
        void __fastcall Paste1Click(TObject *Sender);
        void __fastcall Delete1Click(TObject *Sender);
        void __fastcall Selectall1Click(TObject *Sender);
private:	// D�clarations utilisateur
public:		// D�clarations utilisateur
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
