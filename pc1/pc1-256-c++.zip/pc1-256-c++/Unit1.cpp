/*
   ################################################
   #                                              #
   #  PC1 CIPHER 256-bit keys ~ Alexander Pukall  #
   #  (c) NERRANT THOMAS ~ February 2003          #
   #  http://thomasnerrant.com                    #
   #                                              #
   ################################################
*/
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
//Initialization
unsigned short ax,bx,cx,dx,si,tmp,x1a2,x1a0[16],res,i,inter,cfc,cfd,compte;
unsigned char cle[32]; /* les variables sont definies de facon globale */
unsigned char buff[32];
short c;
int c1,count;
short d,e;
int size;
char *buf;
//---------------------------------------------------------------------------
//Algorithm
fin()
{
/* erase all variables */

for (compte=0;compte<=31;compte++)
{
cle[compte]=0;
}
ax=0;
bx=0;
cx=0;
dx=0;
si=0;
tmp=0;
x1a2=0;
x1a0[0]=0;
x1a0[1]=0;
x1a0[2]=0;
x1a0[3]=0;
x1a0[4]=0;
res=0;
i=0;
inter=0;
cfc=0;
cfd=0;
compte=0;
c=0;

return(0);
}
//////////////////////////////////////////////////////////////////////////////
code()
{
dx=x1a2+i;
ax=x1a0[i];
cx=0x015a;
bx=0x4e35;

tmp=ax;
ax=si;
si=tmp;

tmp=ax;
ax=dx;
dx=tmp;

if (ax!=0)
{
ax=ax*bx;
}

tmp=ax;
ax=cx;
cx=tmp;

if (ax!=0)
{
ax=ax*si;
cx=ax+cx;
}

tmp=ax;
ax=si;
si=tmp;
ax=ax*bx;
dx=cx+dx;

ax=ax+1;

x1a2=dx;
x1a0[i]=ax;

res=ax^dx;
i=i+1;
return(0);
}
///////////////////////////////////////////////////////////////////////////////
assemble()
{

x1a0[0]= ( cle[0]*256 )+ cle[1];
code();
inter=res;

x1a0[1]= x1a0[0] ^ ( (cle[2]*256) + cle[3] );
code();
inter=inter^res;

x1a0[2]= x1a0[1] ^ ( (cle[4]*256) + cle[5] );
code();
inter=inter^res;

x1a0[3]= x1a0[2] ^ ( (cle[6]*256) + cle[7] );
code();
inter=inter^res;

x1a0[4]= x1a0[3] ^ ( (cle[8]*256) + cle[9] );
code();
inter=inter^res;

x1a0[5]= x1a0[4] ^ ( (cle[10]*256) + cle[11] );
code();
inter=inter^res;

x1a0[6]= x1a0[5] ^ ( (cle[12]*256) + cle[13] );
code();
inter=inter^res;

x1a0[7]= x1a0[6] ^ ( (cle[14]*256) + cle[15] );
code();
inter=inter^res;

x1a0[8]= x1a0[7] ^ ( (cle[16]*256) + cle[17] );
code();
inter=inter^res;

x1a0[9]= x1a0[8] ^ ( (cle[18]*256) + cle[19] );
code();
inter=inter^res;

x1a0[10]= x1a0[9] ^ ( (cle[20]*256) + cle[21] );
code();
inter=inter^res;

x1a0[11]= x1a0[10] ^ ( (cle[22]*256) + cle[23] );
code();
inter=inter^res;

x1a0[12]= x1a0[11] ^ ( (cle[24]*256) + cle[25] );
code();
inter=inter^res;

x1a0[13]= x1a0[12] ^ ( (cle[26]*256) + cle[27] );
code();
inter=inter^res;

x1a0[14]= x1a0[13] ^ ( (cle[28]*256) + cle[29] );
code();
inter=inter^res;

x1a0[15]= x1a0[14] ^ ( (cle[30]*256) + cle[31] );
code();
inter=inter^res;

i=0;
return(0);
}
/////////////////////////////////////////////////////////////////////////////
// Common function to coding and decoding
bool common(){
/* ('abcdefghijklmnopqrstuvwxyz012345') is the default password used*/
/* if the user enter a key < 32 characters, characters of the default */
/* password will be used */
strcpy(cle,"abcdefghijklmnopqrstuvwxyz012345");

///////////////////////////////////////////
//Key stocked in 'buff'
size=Form1->Edit1->GetTextLen()+1;
if(size!=1){
Form1->Edit1->GetTextBuf(buff,size);
}else{
ShowMessage("You must enter de password");
return 1;
}
///////////////////////////////////////////

if ((size-1)>32)
{ count=32; }
else
{count=(size-1);}

for (c1=0;c1<count;c1++)
{
cle[c1]=buff[c1];
}

////////////////////////////////////////
// Text from RichEdit1 stocked in buf
if(Form1->Button1->Focused())
size=Form1->RichEdit1->GetTextLen()+1;
else
size=Form1->RichEdit2->GetTextLen()+1;
if(size!=1){
buf=new char[size];
buf[size-1]=0;
if(Form1->Button1->Focused())
Form1->RichEdit1->GetTextBuf(buf,size);
else
Form1->RichEdit2->GetTextBuf(buf,size);
}else{
ShowMessage("You must enter a text");
return 1;
}
////////////////////////////////////////
return 0;
}
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label2Click(TObject *Sender)
{
try{
ShellExecute(this->Handle,"open","http://thomasnerrant.com",0,0,SW_NORMAL);
}catch(...){}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
char *result;
try{

if(common()==0){

/////////////////////////////////
// Creation of a table result to
// stock the result after coding
result=new char[size*2-1];
result[size*2-2]=0;
/////////////////////////////////

int j=0;

for(int i=0;i<size;i++){
c=buf[i];
assemble();
cfc=inter>>8;
cfd=inter&255; /* cfc^cfd = random byte */

/* K ZONE !!!!!!!!!!!!! */
/* here the mix of c and cle[compte] is before the encryption of c */

for (compte=0;compte<=31;compte++)
{
/* we mix the plaintext byte with the key */

cle[compte]=cle[compte]^c;
}

c = c ^ (cfc^cfd);

d=(c >> 4); /* we split the 'c' crypted byte into two 4 bits parts 'd' and 'e' */
e=(c & 15);

result[j]=(0x61+d);
result[j+1]=(0x61+e);
j=j+2;
}
RichEdit2->Text=result;
fin();
delete buf;
delete result;
}
}catch(...){delete buf;delete result;}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
char *result;
try{

common();

///////////////////////////////////
// Creation of a table result to
// stock the result after decoding
result=new char[size/2];
for(int i=0;i<(size/2+1);i++)
result[i]=0;
///////////////////////////////////
int j=0;

for(int i=0;i<size;i=i+2){
d=buf[i];
e=buf[i+1]; /* read the second letter in the file */

d=d-0x61; /* retrieve the 4 bits from the first letter */
d=d<<4;

e=e-0x61; /* retrieve the 4 bits from the second letter */
c=d+e; /* 4 bits of the first letter + 4 bits of the second = 8 bits */

assemble();
cfc=inter>>8;
cfd=inter&255; /* cfc^cfd = random byte */

/* K ZONE !!!!!!!!!!!!! */
/* here the mix of c and cle[compte] is after the decryption of c */

c = c ^ (cfc^cfd);

for (compte=0;compte<=31;compte++)
{
/* we mix the plaintext byte with the key */
cle[compte]=cle[compte]^c;
}

result[j]=c;
j++;
}
RichEdit1->Text=result;
fin();
delete buf;
delete result;
}catch(...){delete buf;delete result;}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Undo1Click(TObject *Sender)
{
if(RichEdit1->Focused())
RichEdit1->Undo();
if(RichEdit2->Focused())
RichEdit2->Undo();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Copy1Click(TObject *Sender)
{
if(RichEdit1->Focused())
RichEdit1->CopyToClipboard();
if(RichEdit2->Focused())
RichEdit2->CopyToClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Paste1Click(TObject *Sender)
{
if(RichEdit1->Focused())
RichEdit1->PasteFromClipboard();
if(RichEdit2->Focused())
RichEdit2->PasteFromClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Delete1Click(TObject *Sender)
{
if(RichEdit1->Focused())
RichEdit1->Clear();
if(RichEdit2->Focused())
RichEdit2->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Selectall1Click(TObject *Sender)
{
if(RichEdit1->Focused())
RichEdit1->SelectAll();
if(RichEdit2->Focused())
RichEdit2->SelectAll();
}
//---------------------------------------------------------------------------
