The PC1 Encryption Algorithm
Alexander Pukall 1991
Code free for all
PC1COD128.c : the encryption algorithm
PC1DEC128.c : the decryption algorithm
The PC1 cipher uses a 128-bit key.
It's a stream cipher with a retroaction function.
Tested with Turbo C 2.0 for DOS
and Microsoft Visual C++ 5.0 for Win 32
This code is used in the PEDIT software ( author : Paul Brand )
and CRYPTOGRAPHE 98 ( author : Peter Torris )


