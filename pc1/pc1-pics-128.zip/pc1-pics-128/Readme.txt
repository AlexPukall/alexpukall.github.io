The assembler code was compiled with PIC Simulator IDE (in Basic)
(c) Alexander Pukall 1991-2004
Code free for all, even for commercial applications

The PC1 Encryption Cipher uses 128-bit keys

Explanation for PC1.BAS

cle(0) = 78
cle(1) = 84
cle(2) = 45
cle(3) = 13
cle(4) = 124
cle(5) = 212
cle(6) = 49
cle(7) = 52
cle(8) = 178
cle(9) = 243
cle(10) = 17
cle(11) = 221
cle(12) = 74
cle(13) = 153
cle(14) = 237
cle(15) = 85

This is the 128-bit key (16 bytes)
You can change it as you want, it's like a password.

' the plaintext is 97 97 97 97 97 97 97 97 97 (in decimal) Or 'aaaaaaaa' (in ASCII)

inputalgo(0) = 97
inputalgo(1) = 97
inputalgo(2) = 97
inputalgo(3) = 97
inputalgo(4) = 97
inputalgo(5) = 97
inputalgo(6) = 97
inputalgo(7) = 97
inputalgo(8) = 97

This is the plaintext, in the example it's the string 'aaaaaaaaa' a 9 bytes string.

It could be greater, 100 bytes for example. Inputalgo should be define to inputalgo(100)

outputalgo() contains the encrypted bytes if you run the algo in encryption mode (modealgo = 1)

outputalgo() contains the decrypted bytes if you run the algo in decryption mode (modealgo = 2), but then inputalgo() should contains the encrypted bytes

look at the pc1.bas source code or directly in the .asm source code for more details.





