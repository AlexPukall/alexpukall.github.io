//	    ------------------------------------
//	        PC1 v1.1  par Fran�ois LEIBER
//	           http://leiber.free.fr/
//	        francois.leiber@laposte.net
//	            Compil� avec Ti-gcc
//	   Librairies document�es par Zeljko Juric
//	                01/04/2001
//	    ------------------------------------


#define OPTIMIZE_ROM_CALLS
#define NO_EXIT_SUPPORT

#include <tigcclib.h>

short _ti89 ;
short _ti92plus ;

unsigned short si = 0, x1a2 = 0, res = 0, i = 0, inter = 0, cfc = 0, cfd = 0 ;
unsigned short x1a0[5] = {} ;
unsigned char cle[11] = {} ;


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

unsigned char* mk_var(SYM_ENTRY *entry, unsigned char *nom, unsigned short taille)
{
	si = 0 ;

	if (entry->flags.bits.archived != 0)		// V�rifie que la variable n'est pas archiv�e
	{
		EM_moveSymFromExtMem(nom, HS_NULL) ;
		si = 1 ;
	}
	SymDel(nom) ;
	entry = DerefSym(SymAdd(nom)) ;				// Cr�e la nouvelle variable apr�s avoir effac� l'ancienne

	return (unsigned char*)HeapDeref(entry->handle = HeapAlloc(taille)) ;	// Lui alloue 'taille' octets
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void code(void)
{
	short ax, bx, cx, dx ;

	ax = x1a0[i] ;
	bx = 0x4e35 ;
	cx = x1a2+i ;
	dx = si ;
	si = 0x015a ;

	cx *= bx ;
	si *= ax ;
	cx += si ;
	ax *= bx ;
	dx += cx ;

	x1a2 = dx ;
	x1a0[i] = ++ax ;
	res = ax^dx ;
	i++ ;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void assemble(void)
{
	i = 0 ;

	x1a0[0] = *(unsigned short*)cle ;
	code() ;
	inter = res ;

	x1a0[1] = x1a0[0] ^ (*(unsigned short*)(cle+2)) ;
	code() ;
	inter = inter^res ;

	x1a0[2] = x1a0[1] ^ (*(unsigned short*)(cle+4)) ;
	code() ;
	inter = inter^res ;

	x1a0[3] = x1a0[2] ^ (*(unsigned short*)(cle+6)) ;
	code() ;
	inter = inter^res ;

	x1a0[4] = x1a0[3] ^ (*(unsigned short*)(cle+8)) ;
	code() ;
	inter = inter^res ;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void _main()
{
	unsigned short taille, encode, c, j ;
	unsigned char *nom, *var, *crypt, *limite, *ptr ;
	unsigned char name[18], extension[] = {0, 99, 114, 121, 112, 0, OTH_TAG} ;
	SYM_ENTRY *entry ;
	ESI arg ;

	OSSetSR(0x0700) ;
	si = 0 ;
	x1a2 = 0 ;

	InitArgPtr(arg) ;								// Initialise la liste des arguments

	if (GetArgType(arg) != STR_TAG) goto Fin ;

	name[0] = 0 ;
	strncpy(name+1, GetStrnArg(arg), 17);			// R�cup�re le premier argument, nom de la variable
	nom = name+1+strlen(name+1) ;
	entry = SymFindPtr(nom, 0) ;
	if (entry == NULL) goto Fin ;
	var = (unsigned char*)HLock(entry->handle) ;	// R�cup�re un pointeur vers la variable, et v�rouille celle-ci

	if (GetArgType(arg) != STR_TAG)					// R�cup�re le deuxi�me argument, la cl� de cryptage		
	{
		HeapUnlock(entry->handle) ;
		goto Fin ;
	}
	memset(cle, 0x99, 10) ;
	strncpy(cle, GetStrnArg(arg), 10) ;				// Copie la cl� de cryptage dans 'cle'

	taille = *(unsigned short*)var+2 ;
	if ((crypt = malloc(taille+2)) == 0)			// Alloue de la place pour stocker la variable (d�)crypt�e
	{
		HeapUnlock(entry->handle) ;
		goto Fin ;
	}
	limite = var+taille ;

	if (memcmp(var+taille-7, extension, 7) == 0)	// Regarde si c'est une variable crypt�e ou non
	{
		ST_helpMsg("Decoding...") ;					// Elle est d�j� crypt�e...
		encode = 0 ;
		limite -= 7 ;
		ptr = crypt ;
		var += 2 ;
	}
	else
	{
		ST_helpMsg("Encoding...") ;					// ou elle ne l'est pas.
		encode = 1 ;
		*(unsigned short*)crypt = taille+7 ;
		ptr = crypt+2 ;
	}

	for ( ; var < limite ; var++, ptr++)			// Parcourt toute la variable
	{
		c = *var ;
		assemble() ;
		cfc = inter>>8 ;
		cfd = inter&255 ;

		if (encode == 0) c = c^(cfc^cfd) ;				// D�cryptage, on m�lange apr�s avec la cl�
		for (j = 0 ; j < 10 ; j++) cle[j] = cle[j]^c ;
		if (encode != 0) c = c^(cfc^cfd) ;				// Cryptage, on m�lange d'abord avec la cl�
			
		*ptr = c ;
	}

	if (encode != 0)
	{
		var = mk_var(entry, nom, taille+9) ;		// Cryptage : cr�e la nouvelle variable crypt�e, puis recopie le tampon dedans
		memcpy(var, crypt, taille+2) ;
		memcpy(var+taille+2, extension, 7) ;
		if (si != 0) EM_moveSymToExtMem(nom, HS_NULL) ;
	}
	else if (*(unsigned short*)crypt == taille-11)					// V�rifie que le code a des chances d'�tre bon
	{
		memcpy(mk_var(entry, nom, taille+9), crypt, taille-9) ;		// Si oui, recr�e la variable non crypt�e
		if (si != 0) EM_moveSymToExtMem(nom, HS_NULL) ;
	}


	free(crypt) ;

	Fin:
	ST_helpMsg("PC1 v1.11 by Fran�ois Leiber") ;
	
	return ;
}
