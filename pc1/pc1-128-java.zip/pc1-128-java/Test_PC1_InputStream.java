/* This file is a quick test for the PC1_InputStream */
/* It will unencrypt a given file, using the above class */

import java.io.*;

public class Test_PC1_InputStream
{
      public static void main(String s[]) throws FileNotFoundException, IOException
      {
	 System.out.println("Test for PC1_InputStream.");
	 
	 if (s.length!=3) {
	    System.out.println("USAGE: javac Test_PC1_InputStream in_encrypted_file out_plain_file password.");
	    System.exit(-1);
	 }

	 System.out.println();

	 PC1_InputStream in = new PC1_InputStream(new FileInputStream(s[0]),s[2].getBytes());
	 FileOutputStream out = new FileOutputStream(s[1]);

	 int c = in.read();

	 while (c != -1)
	 {
	    out.write(c);
	    
	    c = in.read();
	 }
	 
	 System.out.println("done");
      }
}
