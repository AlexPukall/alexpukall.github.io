Port to Java by Robert Neild
Only minimum changes made
Chars where used as an easy replacement for unsigned ints

The PC1 Encryption Algorithm
Alexander Pukall 2004
Code free for all even for commercial applications

The PC1 cipher uses a 128-bit key.
It's a stream cipher with a retroaction function.


Usage :

You must have JAVA installed on your computer

To encrypt type :

java Test_PC1_OutputStream a.doc a.cry topsecret

with a.doc the name of the file to encrypt (a word file,a picture file, a binary file, a text file ...)

with a.cry the name of the encrypted output file

with topsecret the password


To decrypt type :

java Test_PC1_InputStream a.cry a.doc topsecret

with a.cry the name of the encrypted file

with a.doc the name of the file which will be decrypted

with topsecret the password

