/* Quick test for PC1_InputStream */
/* Takes a plain file, and encrypts is */

import java.io.*;

public class Test_PC1_OutputStream
{
      public static void main(String s[]) throws FileNotFoundException, IOException
      {
	 System.out.println("Test of PC1_OutputStream.");
	 
	 if (s.length!=3) {
	    System.out.println("USAGE: javac Test_PC1_OutputStream in_plain_file_name out_encrypted_file_name password.");
	    System.exit(-1);
	 }

	 System.out.println();

	 PC1_OutputStream out = new PC1_OutputStream(new FileOutputStream(s[1]),s[2].getBytes());
	 FileInputStream in = new FileInputStream(s[0]);

	 int c = in.read();

	 while (c != -1)
	 {
	    out.write(c);
	    
	    c = in.read();
	 }
	 
	 System.out.println("done");
      }
}
