PC1 PUKALL CIPHER 1
(c) Alexandre PUKALL 1991

Crypto algorithm with high security ( 128-bit keys )

Free use even commercial use if the name of the author
is indicated in the software.


