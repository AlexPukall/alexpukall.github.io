The PC1 Encryption Algorithm
Alexander Pukall 1991
Code free for all
PC1COD.c : the encryption algorithm
PC1DEC.c : the decryption algorithm
The PC1 cipher uses a 256-bit key.
It's a stream cipher with a retroaction function.
Tested with Turbo C 2.0 for DOS
and Microsoft Visual C++ 5.0 for Win 32

Run PC1DEC.EXE, this will decrypt the included file OUT.BIN
the password is 'testtest'


